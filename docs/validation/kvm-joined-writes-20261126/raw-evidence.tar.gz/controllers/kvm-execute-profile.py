from pathlib import Path
import json,os,subprocess,sys,shutil
project=Path('/home/main.guest/trames-linux-wsi-qualified');sys.path.insert(0,str(project/'runtime/tests/acceptance'))
from common import digest,save
from run import receipt,execute,host
out=Path('/home/main.guest/trames-kvm-execute-profile-v1');out.mkdir(exist_ok=False)
runner=Path('/home/main.guest/trames-kvm-timer-fuse-runner');build=receipt(Path('/home/main.guest/trames-kvm-timer-fuse-build.json'),runner)
root=Path('/home/main.guest/trames-kvm-timer-before-performance/rootfs')
save(out/'inputs.json',dict(build=build,host=host(),fixture_sha256=digest(root/'test/performance'),controller_sha256=digest(Path(__file__)),instrumented=True,primary_performance=False,method='199Hz software cpu-clock + 4KiB DWARF callchain; flat and callgraph reports; delete raw stack captures after report'))
rows=[]
for mode,count,workers,transport in [('getpid',100000,1,'smccc'),('getpid',100000,4,'smccc'),('getpid',100000,1,'mmio'),('cpu',500000000,1,'smccc')]:
 folder=out/f'{mode}-{workers}-{transport}';folder.mkdir();data=folder/'perf.data';work=root/'work/profile';work.mkdir(parents=True)
 command=['sudo','-n','env','PATH=/usr/bin:/bin','HOME=/tmp','LANG=C','LC_ALL=C','TZ=UTC','TRAMES_KVM_TRANSPORT='+transport,'perf','record','-q','-F','199','-e','cpu-clock','--call-graph','dwarf,4096','-o',str(data),'--','taskset','-c',','.join(str(i) for i in range(2,2+workers)),str(runner),'run','--cpus',str(workers),'--rootfs',str(root),'--timeout-ms','60000','--','/test/performance',mode,str(count),str(workers),'/work/profile']
 save(folder/'command.json',dict(argv=command))
 result=execute(command,os.environ.copy(),folder,65)
 assert result['exit_code']==0 and result['status']=='completed',result
 value=json.loads((folder/'stdout').read_text());assert value['mode']==mode and value['iterations']==count and value['concurrency']==workers
 for kind,args in [('flat',['--no-children','--sort','comm,dso,symbol']),('callgraph',['--children','-g','graph,0.5,caller'])]:
  with (folder/(kind+'.txt')).open('wb') as stream:
   subprocess.run(['sudo','-n','perf','report','--stdio','--percent-limit','0.5','-i',str(data),*args],stdout=stream,stderr=subprocess.STDOUT,check=True)
 raw_bytes=data.stat().st_size
 subprocess.run(['sudo','-n','rm','--',str(data)],check=True)
 row=dict(id=folder.name,**result,raw_stack_bytes_removed=raw_bytes,logs={p.name:digest(p) for p in folder.iterdir() if p.is_file()})
 save(folder/'result.json',row);rows.append(row);print(folder.name,raw_bytes,flush=True)
 work.rmdir()
save(out/'results.json',dict(passed=True,cases=rows,instrumented=True,primary_performance=False))
with __import__('tarfile').open('/mnt/trames-output/kvm-execute-profile-v1.tgz','w:gz') as archive:archive.add(out,arcname='profile')
