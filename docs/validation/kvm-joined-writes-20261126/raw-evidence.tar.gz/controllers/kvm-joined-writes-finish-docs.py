from pathlib import Path
import json,tarfile,sys,importlib.util,hashlib,shutil
repo=Path('/Users/main/dev/trames-linux');out=repo/'docs/validation/kvm-joined-writes-20261126';previous=out.parent/'kvm-timer-reuse-20261126'
raw=Path('/private/tmp/trames-joined-writes-final-evidence');raw.mkdir(exist_ok=False)
shutil.copy2('/Users/main/dev/trames/target/local-ci/io/kvm-joined-writes-raw-evidence.tgz',out/'raw-evidence.tar.gz')
with tarfile.open(out/'raw-evidence.tar.gz','r:gz') as archive:
 for member in archive.getmembers():
  path=Path(member.name);assert not path.is_absolute() and '..' not in path.parts and (member.isfile() or member.isdir())
 archive.extractall(raw)
sys.path.insert(0,str(previous/'audit-support'))
spec=importlib.util.spec_from_file_location('benchmark_report',previous/'audit-controller.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
for name in ['performance','initial-performance','original-performance','retry-performance']:
 assert b.audit(raw/name)==(1 if name=='original-performance' else 0)
 (out/name).mkdir(exist_ok=False)
 for file in ['results.json','report.md']:
  shutil.copy2(raw/name/file,out/name/file)
 p=out/name/'report.md';p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines())+'\n')
data=json.loads((raw/'performance/results.json').read_text());by={(r['mode'],r['workers'],r['lane']):r for r in data['comparisons']}
lines=['| Workload | Workers | Native wall ms | SMCCC before → after ms | SMCCC after/before | MMIO after/before |','| --- | ---: | ---: | ---: | ---: | ---: |']
for mode in ['build','node','getpid','memory']:
 for workers in [1,4]:
  native=by[(mode,workers,'native')];base=by[(mode,workers,'baseline-smccc')];candidate=by[(mode,workers,'candidate-smccc')];mmio=by[(mode,workers,'candidate-mmio')]
  ms=lambda row:row['metrics']['wall_ns']['median']/1e6
  lines.append(f"| {mode} | {workers} | {ms(native):.3f} | {ms(base):.3f} → {ms(candidate):.3f} | {candidate['wall_time_ratio_to_baseline']:.3f} | {mmio['wall_time_ratio_to_baseline']:.3f} |")
checks='''| Check | Result |
| --- | --- |
| Strict workspace Clippy and normal tests | Passed |
| Real KVM library/hardware matrix | 36/36, both transports |
| 4 KiB original core memory matrix | 77/77 |
| Original CPU extension/state/ptrace | 15/15 |
| Declared application workflows | 48/48 KVM; independently checked native 12-case reference reused |
| Original libfuse | 108 functional plus 36 shutdown checks |
| 4 KiB software Vulkan/KVM buffer aliases | 2/2; original bytes in both directions and read-only neighbors |

The new real-KVM regression exercises three consecutive SVCs per View, four joined writebacks, switches to another address space, protection and replacement of the original backing. No full network/systemd/Docker or physical-device corpus is repeated.

Each full interleaved schedule retains 240 executions, including 180 measured samples and 60 calibrations/warmups. The first-candidate schedule passes. The final schedule's original audit rejects one baseline build sample because make emits a clock-skew warning; its exit and object checksum match native. The complete failed result remains in [original-performance](kvm-joined-writes-20261126/original-performance/report.md).

A scoped [supplemental build round](kvm-joined-writes-20261126/retry-performance/report.md) runs native and both transports/versions together, with calibration and warmups: ten executions. The qualified derived view replaces the entire affected five-lane measured round, including its four otherwise valid samples. Source rows, repeats and log bytes are retained unchanged under explicit origin metadata; the fixed selection rule is independently audited. No timing-based sample selection or stderr exception is allowed. The supplemental build's executable/library hashes match the corresponding original inputs; its rootfs omits unused Node files.

There are 490 retained raw executions across both candidates and the supplement. Each candidate's qualified view contains 240 selected executions/180 measured samples; the final view is explicitly a paired-round reconstruction. These are two separate candidates, not six independent repeats of one candidate. The warning alone does not identify whether virtual-clock synchronization or the guest wall-clock path caused the mismatch; wall-clock/stat consistency remains a separate investigation.

The final candidate's wall-time medians are below. Work/CPU/resource distributions remain in the [complete report](kvm-joined-writes-20261126/performance/report.md); first-candidate data remains in the [initial report](kvm-joined-writes-20261126/initial-performance/report.md). Lower ratios are faster on this configuration; these small samples do not establish a universal speedup.

'''+ '\n'.join(lines)
audit='''```sh
PYTHONDONTWRITEBYTECODE=1 python3 docs/validation/kvm-joined-writes-20261126/audit.py
```

The [offline audit](kvm-joined-writes-20261126/audit-result.json) preserves the original failed audit, verifies its supplemental matched round and the exact reconstructed selection, then verifies both qualified distributions, source/build/tool/fixture bindings, raw logs, original core/CPU outputs, application artifact fingerprints, FUSE activation/shutdown and buffer tests. It reuses the unchanged frozen benchmark auditor and its four previously verified negative-evidence cases; their exact files are pinned by the new index. Two additional provenance checks reject a partial-round selection and a changed derived timing. A repository checkout supplies those earlier frozen helpers. No benchmark or hardware work reruns during audit.

Source and adapter identity are recorded in [source-scope.json](kvm-joined-writes-20261126/source-scope.json), the observed guest PCs in [profile-symbols.json](kvm-joined-writes-20261126/profile-symbols.json), and independent cross-platform source checks in [cloud-checks.json](kvm-joined-writes-20261126/cloud-checks.json). Raw archives exclude executables, rootfs/library copies and perf stack captures. The first compile-time MemoryError conversion diagnostic is retained; the corrected source passes the scoped checks.
'''
p=Path('/Users/main/dev/trames/target/local-ci/io/kvm-joined-writes-report-draft.md');text=p.read_text().replace('RESULTS_PENDING',checks).replace('AUDIT_PENDING',audit)
text=text.replace('`c095588` (full identity and successful build receipt in the raw archive).','`c0955881e5554c659f8e15dc1c1c4cf129f02607`, runner SHA-256 `345289fd15f4fad74ccc971ccfcefbd725919c12f049e7c3c914c06ee77590e4`.')
text=text.replace('The compact revision removes private-page token storage and the temporary full-binding vector;','The compact revision removes private-page token storage and the temporary full-binding vector; these two runs do not separately isolate that layout change from scheduling and first-use-translation variation. It')
# Keep the resulting sentence grammatical after the added scope qualifier.
text=text.replace('It it preserves','It preserves').replace('It it preserves','It preserves')
(out.with_suffix('.md')).write_text(text)
refs=['../kvm-timer-reuse-20261126/audit-controller.py','../kvm-timer-reuse-20261126/audit-support/common.py','../kvm-timer-reuse-20261126/audit-support/run.py','../kvm-timer-reuse-20261126/audit-result.json']
files={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ['evidence-index.json','audit-result.json']}
files.update({name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in refs})
(out/'evidence-index.json').write_text(json.dumps({'schema_version':1,'files':files},indent=2)+'\n')
print('prepared',out,'archive bytes',(out/'raw-evidence.tar.gz').stat().st_size)
