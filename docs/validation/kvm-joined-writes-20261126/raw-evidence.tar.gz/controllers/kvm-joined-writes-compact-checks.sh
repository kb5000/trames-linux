#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git -c fetch.recurseSubmodules=false fetch /mnt/trames-output/kvm-joined-writes-compact-root.bundle HEAD
git merge --ff-only --no-stat FETCH_HEAD
cargo clippy --workspace --all-targets --release --locked -- -D warnings > /home/main.guest/trames-kvm-joined-writes-compact-clippy.log 2>&1
cargo test --workspace --release --locked > /home/main.guest/trames-kvm-joined-writes-compact-unit.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport cargo test -p trames-kvm --lib --test hardware --release --locked -- --ignored --test-threads=1 > /home/main.guest/trames-kvm-joined-writes-compact-hardware-$transport.log 2>&1
done
for transport in smccc mmio; do
 driver=$(python3 -c 'from pathlib import Path; print(next(Path("/usr/share/vulkan/icd.d").glob("*lvp*")))')
 VK_DRIVER_FILES="$driver" TRAMES_KVM_TRANSPORT=$transport cargo test -p trames-kvm --test vulkan --release --locked -- --ignored --test-threads=1 > /home/main.guest/trames-kvm-joined-writes-compact-vulkan-$transport.log 2>&1
done
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-joined-writes-compact-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-joined-writes-compact-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-joined-writes-compact-runner
python3 tests/acceptance/validate-memory.py --runner /home/main.guest/trames-kvm-joined-writes-compact-runner --receipt /home/main.guest/trames-kvm-joined-writes-compact-build.json --output /home/main.guest/trames-kvm-joined-writes-compact-memory > /home/main.guest/trames-kvm-joined-writes-compact-memory.log 2>&1
python3 scripts/validate-cpu.py --runner /home/main.guest/trames-kvm-joined-writes-compact-runner --receipt /home/main.guest/trames-kvm-joined-writes-compact-build.json --output /home/main.guest/trames-kvm-joined-writes-compact-cpu > /home/main.guest/trames-kvm-joined-writes-compact-cpu.log 2>&1
python3 scripts/validate-applications.py --bundle /home/main.guest/trames-acceptance-bundle-v3 --runner /home/main.guest/trames-kvm-joined-writes-compact-runner --receipt /home/main.guest/trames-kvm-joined-writes-compact-build.json --reference /home/main.guest/trames-applications-final-native --output /home/main.guest/trames-kvm-joined-writes-compact-applications > /home/main.guest/trames-kvm-joined-writes-compact-applications.log 2>&1
