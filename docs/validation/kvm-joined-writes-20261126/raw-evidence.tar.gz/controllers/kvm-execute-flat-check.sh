#!/bin/sh
set -eu
root=/home/main.guest/trames-kvm-timer-before-performance/rootfs
out=/home/main.guest/trames-kvm-execute-profile-v2
mkdir "$out"
mkdir "$root/work/profile-flat"
sudo -n env PATH=/usr/bin:/bin HOME=/tmp LANG=C LC_ALL=C TZ=UTC TRAMES_KVM_TRANSPORT=smccc perf record -q -F 499 -e cpu-clock -o "$out/perf.data" -- taskset -c 2 /home/main.guest/trames-kvm-timer-fuse-runner run --cpus 1 --rootfs "$root" --timeout-ms 30000 -- /test/performance getpid 100000 1 /work/profile-flat > "$out/stdout" 2> "$out/stderr"
sudo -n perf report --stdio --header --no-children -g none --sort dso,symbol --percent-limit 0 --show-nr-samples -i "$out/perf.data" > "$out/flat.txt" 2>&1
sudo -n perf report --stdio --header --no-children -g none --sort dso,symbol --percent-limit 0 --show-nr-samples --guest -i "$out/perf.data" > "$out/guest.txt" 2>&1 || true
sudo -n perf script -F event,ip,sym,dso -i "$out/perf.data" > "$out/symbol-samples.txt" 2> "$out/script.stderr"
sudo -n rm -- "$out/perf.data"
rmdir "$root/work/profile-flat"
tar -czf /mnt/trames-output/kvm-execute-profile-v2.tgz -C "$out" .
