from pathlib import Path
import os,tarfile
base=Path('/home/main.guest')
paths={
 'trames-kvm-joined-writes-qualified-performance':'performance',
 'trames-kvm-joined-writes-compact-performance':'original-performance',
 'trames-kvm-joined-writes-build-retry':'retry-performance',
 'trames-kvm-joined-writes-final-performance':'initial-performance',
 'trames-kvm-joined-writes-compact-memory':'memory',
 'trames-kvm-joined-writes-compact-cpu':'cpu',
 'trames-kvm-joined-writes-compact-applications':'applications',
 'trames-kvm-joined-writes-compact-fuse':'fuse',
 'trames-applications-final-native':'applications-native',
 'trames-kvm-execute-profile-v1':'profile-v1',
 'trames-kvm-execute-profile-v2':'profile-v2',
 'trames-kvm-execute-profile-v3':'profile-v3',
}
with tarfile.open('/mnt/trames-output/kvm-joined-writes-raw-evidence.tgz','w:gz',dereference=True) as archive:
 for source,target in paths.items():
  root=base/source;assert root.is_dir(),root
  for folder,dirs,names in os.walk(root):
   dirs[:]=[d for d in dirs if d not in ['rootfs','.git','__pycache__']]
   for name in names:
    file=Path(folder)/name
    if not file.is_file() or file.is_symlink() or name.startswith('perf.data'):continue
    with file.open('rb') as stream:magic=stream.read(4)
    if magic==b'\x7fELF':continue
    archive.add(file,arcname=str(Path(target)/file.relative_to(root)),recursive=False)
 for file in base.glob('trames-kvm-joined-writes-*.log'):archive.add(file,arcname='logs/'+file.name,recursive=False)
 for name,target in [('trames-kvm-joined-writes-compact-build.json','build.json'),('trames-kvm-joined-writes-final-build.json','initial-build.json'),('trames-kvm-timer-fuse-build.json','baseline-build.json')]:archive.add(base/name,arcname=target,recursive=False)
 for file in Path('/mnt/trames-output').glob('kvm-joined-writes-*.py'):archive.add(file,arcname='controllers/'+file.name,recursive=False)
 for file in Path('/mnt/trames-output').glob('kvm-joined-writes-*.sh'):archive.add(file,arcname='controllers/'+file.name,recursive=False)
 for name in ['kvm-execute-profile.py','kvm-execute-flat-check.sh','kvm-execute-complete-profile.sh']:
  archive.add(Path('/mnt/trames-output')/name,arcname='controllers/'+name,recursive=False)
print('raw archive bytes',Path('/mnt/trames-output/kvm-joined-writes-raw-evidence.tgz').stat().st_size)
