#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git -c fetch.recurseSubmodules=false fetch /mnt/trames-output/kvm-joined-writes-root.bundle HEAD
git merge --ff-only --no-stat FETCH_HEAD
cargo clippy --workspace --all-targets --release --locked -- -D warnings > /home/main.guest/trames-kvm-joined-writes-clippy.log 2>&1
cargo test --workspace --release --locked > /home/main.guest/trames-kvm-joined-writes-unit.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport cargo test -p trames-kvm --lib --test hardware --release --locked -- --ignored --test-threads=1 > /home/main.guest/trames-kvm-joined-writes-hardware-$transport.log 2>&1
done
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-joined-writes-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-joined-writes-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-joined-writes-runner
python3 tests/acceptance/validate-memory.py --runner /home/main.guest/trames-kvm-joined-writes-runner --receipt /home/main.guest/trames-kvm-joined-writes-build.json --output /home/main.guest/trames-kvm-joined-writes-memory > /home/main.guest/trames-kvm-joined-writes-memory.log 2>&1
python3 scripts/validate-cpu.py --runner /home/main.guest/trames-kvm-joined-writes-runner --receipt /home/main.guest/trames-kvm-joined-writes-build.json --output /home/main.guest/trames-kvm-joined-writes-cpu > /home/main.guest/trames-kvm-joined-writes-cpu.log 2>&1
python3 scripts/validate-applications.py --bundle /home/main.guest/trames-acceptance-bundle-v3 --runner /home/main.guest/trames-kvm-joined-writes-runner --receipt /home/main.guest/trames-kvm-joined-writes-build.json --reference /home/main.guest/trames-applications-final-native --output /home/main.guest/trames-kvm-joined-writes-applications > /home/main.guest/trames-kvm-joined-writes-applications.log 2>&1
