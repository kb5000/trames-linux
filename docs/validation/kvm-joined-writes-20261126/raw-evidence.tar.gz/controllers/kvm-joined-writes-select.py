from pathlib import Path
import json,shutil,sys,importlib.util
project=Path('/home/main.guest/trames-linux-wsi-qualified')
sys.path.insert(0,str(project/'runtime/tests/acceptance'))
from common import digest,save
spec=importlib.util.spec_from_file_location('benchmark',project/'tests/acceptance/benchmark.py')
benchmark=importlib.util.module_from_spec(spec);spec.loader.exec_module(benchmark)
base=Path('/home/main.guest');original=base/'trames-kvm-joined-writes-compact-performance';retry=base/'trames-kvm-joined-writes-build-retry';out=base/'trames-kvm-joined-writes-qualified-performance'
assert benchmark.audit(original)==1
failure=json.loads((original/'results.json').read_text())
assert failure['failures']==['build-1-sample-1-baseline-smccc','incomplete distribution: build/1/baseline-smccc']
assert benchmark.audit(retry)==0
read=lambda p:json.loads(p.read_text())
a=read(original/'inputs.json');b=read(retry/'inputs.json')
for key in ['build','baseline_build','compiler_version','fixture_sources','affinity','controller_sha256']:
 assert a[key]==b[key],key
assert a['compiler_command'][:-1]==b['compiler_command'][:-1] and a['compiler_command'][-2]=='-o'
assert all(a['host'][k]==b['host'][k] for k in ['os','arch','kernel','page_size','libc'])
assert all(a['versions'][k]==v for k,v in b['versions'].items())
assert all(a['immutable_files'][k]==v for k,v in b['immutable_files'].items())
assert b['workloads']==['build'] and b['workers']==[1] and b['repeats']==1
out.mkdir(exist_ok=False)
inputs=dict(a);rows=[];plan=[];excluded=[]
for origin,source in [('original',original),('retry',retry)]:
 source_rows=read(source/'samples.json');source_plan={r['id']:r for r in read(source/'inputs.json')['planned_cases']}
 for row in source_rows:
  affected=row['mode']=='build' and row['workers']==1 and row['phase']=='sample' and row['repeat']==1
  selected=not affected if origin=='original' else row['phase']=='sample'
  if not selected:
   excluded.append(dict(origin=origin,id=row['id'],reason='entire original matched round excluded after baseline clock warning' if origin=='original' else 'supplemental calibration/warmup audited independently'))
   continue
  identity=origin+'/'+row['id'];folder=out/'cases'/identity;folder.mkdir(parents=True)
  for name in row['logs']:
   shutil.copy2(source/'cases'/row['id']/name,folder/name)
  derived=dict(row,id=identity,origin=dict(dataset=origin,id=row['id']))
  save(folder/'result.json',derived);rows.append(derived);plan.append(dict(source_plan[row['id']],id=identity))
inputs['planned_cases']=plan;inputs['planned_ids']=[r['id'] for r in plan]
inputs['derivation']=dict(method='replace one entire build/1 measured matched round, not individual favorable samples; preserve original IDs/repeats in origin',controller_sha256=digest(Path(__file__)),sources={k:dict(inputs_sha256=digest(p/'inputs.json'),samples_sha256=digest(p/'samples.json')) for k,p in [('original',original),('retry',retry)]},excluded=excluded)
save(out/'inputs.json',inputs);save(out/'samples.json',rows)
assert len(rows)==240 and sum(r['phase']=='sample' for r in rows)==180
assert sum(r['origin']['dataset']=='retry' for r in rows)==5
assert benchmark.audit(out)==0
print('qualified selection:',len(rows),'executions; strict original audit retained as failed; supplemental matched round audited separately')
