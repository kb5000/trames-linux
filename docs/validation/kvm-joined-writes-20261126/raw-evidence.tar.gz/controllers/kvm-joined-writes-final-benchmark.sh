#!/bin/sh
set -eu
cd /home/main.guest/trames-linux-wsi-qualified
python3 tests/acceptance/benchmark.py --runner /home/main.guest/trames-kvm-joined-writes-final-runner --receipt /home/main.guest/trames-kvm-joined-writes-final-build.json --baseline-runner /home/main.guest/trames-kvm-timer-fuse-runner --baseline-receipt /home/main.guest/trames-kvm-timer-fuse-build.json --workload cpu --workload memory --workload getpid --workload mmap --workload build --workload node --workers 1 4 --repeats 3 --output /home/main.guest/trames-kvm-joined-writes-final-performance > /home/main.guest/trames-kvm-joined-writes-final-performance.log 2>&1
