from pathlib import Path
import os,json,hashlib,stat,shutil
base=Path('/home/main.guest');cohort=base/'trames-kvm-joined-writes-final-performance'
assert json.loads((cohort/'results.json').read_text())['passed']
record={'scope':'completed 6259a61 trial only; preserve records, paths of runners, one identical rootfs and all unique binaries','runner_duplicates':[]}
root=base/'trames-kvm-joined-writes-final-applications';canonical=root/'runner';sha=hashlib.sha256(canonical.read_bytes()).hexdigest()
assert sha==json.loads((root/'build.json').read_text())['fingerprint']['binary_sha256']
for lane in ['kvm-smccc-1','kvm-smccc-4','kvm-mmio-1','kvm-mmio-4']:
 folder=root/lane;results=json.loads((folder/'results.json').read_text());assert len(results['cases'])==12 and all(r['status']=='passed' for r in results['cases'])
 path=folder/'runner';assert path.is_file() and not path.is_symlink() and hashlib.sha256(path.read_bytes()).hexdigest()==sha
 old=path.stat();ref=canonical.stat();assert (old.st_uid,old.st_gid,stat.S_IMODE(old.st_mode))==(ref.st_uid,ref.st_gid,stat.S_IMODE(ref.st_mode))
 if old.st_ino==ref.st_ino:continue
 temporary=path.with_name('runner-dedup-link');assert not temporary.exists();os.link(canonical,temporary);os.replace(temporary,path)
 record['runner_duplicates'].append(dict(path=str(path),canonical=str(canonical),sha256=sha,allocated_bytes_before=old.st_blocks*512))
keep=base/'trames-kvm-timer-before-performance/rootfs';remove=cohort/'rootfs'
def files(root):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
left=files(keep);right=files(remove);assert left==right and left
assert all(not (root/'work').exists() or not list((root/'work').iterdir()) for root in [keep,remove])
record['duplicate_rootfs']=dict(kept=str(keep),removed=str(remove),files=len(left),equal_bytes_map_sha256=hashlib.sha256(json.dumps(left,sort_keys=True).encode()).hexdigest(),allocated_bytes_before=sum(p.stat().st_blocks*512 for p in remove.rglob('*') if p.is_file()))
shutil.rmtree(remove)
record['guest_free_bytes_after']=shutil.disk_usage(base).free
Path('/mnt/trames-output/kvm-joined-writes-initial-cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
print('guest_free_bytes_after',record['guest_free_bytes_after'],flush=True)
