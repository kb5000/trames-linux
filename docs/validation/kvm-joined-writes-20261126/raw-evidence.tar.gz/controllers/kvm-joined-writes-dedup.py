from pathlib import Path
import os,json,hashlib,stat,shutil
base=Path('/home/main.guest');rows=[]
for name in ['trames-kvm-timer-applications','trames-kvm-joined-writes-applications']:
 root=base/name;canonical=root/'runner';sha=hashlib.sha256(canonical.read_bytes()).hexdigest()
 build=json.loads((root/'build.json').read_text());assert sha==build['fingerprint']['binary_sha256']
 for lane in ['kvm-smccc-1','kvm-smccc-4','kvm-mmio-1','kvm-mmio-4']:
  folder=root/lane;results=json.loads((folder/'results.json').read_text());assert len(results['cases'])==12 and all(r['status']=='passed' for r in results['cases'])
  path=folder/'runner';assert path.is_file() and not path.is_symlink()
  assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
  old=path.stat();reference=canonical.stat();assert (old.st_uid,old.st_gid,stat.S_IMODE(old.st_mode))==(reference.st_uid,reference.st_gid,stat.S_IMODE(reference.st_mode))
  if old.st_ino==reference.st_ino:continue
  temporary=path.with_name('runner-dedup-link');assert not temporary.exists();os.link(canonical,temporary);os.replace(temporary,path)
  assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
  rows.append(dict(path=str(path),canonical=str(canonical),sha256=sha,allocated_duplicate_bytes_before=old.st_blocks*512))
record=dict(scope='only completed acceptance runner duplicates; preserve every path, bytes, mode and owner via hardlinks',files=rows,reclaimed_allocated_bytes=sum(r['allocated_duplicate_bytes_before'] for r in rows),guest_free_bytes_after=shutil.disk_usage(base).free)
Path('/mnt/trames-output/kvm-joined-writes-dedup.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
