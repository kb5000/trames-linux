from pathlib import Path
import csv,json,os,subprocess,sys
project=Path('/home/main.guest/trames-linux-wsi-qualified');sys.path.insert(0,str(project/'runtime/tests/acceptance'))
from common import digest,save
from run import execute,host,receipt
out=Path('/home/main.guest/trames-kvm-timer-counters');out.mkdir(exist_ok=False)
base=Path('/home/main.guest/trames-kvm-timer-paired-micro');root=base/'rootfs'
builds={};runners={}
for variant in ['before','after']:
 runners[variant]=Path('/home/main.guest/trames-kvm-timer-'+variant)
 builds[variant]=receipt(Path('/home/main.guest/trames-kvm-timer-'+variant+'-build.json'),runners[variant])
requested=['kvm:kvm_exit','syscalls:sys_enter_ioctl','syscalls:sys_enter_timer_create','syscalls:sys_enter_timer_delete','syscalls:sys_enter_timer_settime','syscalls:sys_enter_timer_gettime','syscalls:sys_enter_rt_sigprocmask','syscalls:sys_enter_rt_sigtimedwait','syscalls:sys_enter_gettid','sched:sched_switch']
def exists(event):return subprocess.run(['sudo','-n','test','-e','/sys/kernel/tracing/events/'+event.replace(':','/')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
events=[event for event in requested if exists(event)]
save(out/'inputs.json',dict(host=host(),builds=builds,events=events,missing_events=list(set(requested)-set(events)),controller_sha256=digest(Path(__file__)),instrumented=True,primary_performance=False,perf_version=subprocess.check_output(['perf','--version'],text=True)))
assert len(events)==len(requested),'required tracepoint unavailable'
work=root/'work/counter-diagnostic';work.mkdir()
calibration={(r['mode'],r['workers']):{k:v for k,v in r['work'].items() if k!='work_ns'} for r in json.loads((base/'samples.json').read_text()) if r['phase']=='calibration'}
rows=[]
environment=dict(PATH='/usr/bin:/bin',HOME='/tmp',LANG='C',LC_ALL='C',TZ='UTC')
for mode,workers,count in [('cpu',1,50000000),('getpid',1,10000),('getpid',4,10000)]:
 for variant,transport in [('native',None),('before','smccc'),('after','smccc'),('before','mmio'),('after','mmio')]:
  folder=out/f'{mode}-{workers}-{variant}-{transport or "host"}';folder.mkdir()
  env=environment|({'TRAMES_KVM_TRANSPORT':transport} if transport else {})
  command=[str(root/'test/performance'),mode,str(count),str(workers),str(work)] if variant=='native' else [str(runners[variant]),'run','--cpus',str(workers),'--rootfs',str(root),'--timeout-ms','30000','--','/test/performance',mode,str(count),str(workers),'/work/counter-diagnostic']
  command=['sudo','-n','env',*[k+'='+v for k,v in env.items()],'perf','stat','--no-big-num','-x,','-o',str(folder/'counters.csv'),'-e',','.join(events),'--','taskset','-c',','.join(str(i) for i in range(2,2+workers)),*command]
  save(folder/'command.json',dict(argv=command))
  result=execute(command,os.environ.copy(),folder,35)
  counters={}
  for row in csv.reader((folder/'counters.csv').read_text().splitlines()):
   if len(row)>2 and row[2] in events:
    try:counters[row[2]]=float(row[0])
    except ValueError:counters[row[2]]=None
  try:semantic={k:v for k,v in json.loads((folder/'stdout').read_text()).items() if k!='work_ns'}
  except (ValueError,AttributeError):semantic=None
  passed=result['exit_code']==0 and result['status']=='completed' and semantic==calibration[(mode,workers)] and set(counters)==set(events) and all(v is not None for v in counters.values())
  rows.append(dict(id=folder.name,mode=mode,workers=workers,variant=variant,transport=transport,**result,passed=passed,counters=counters,logs={name:digest(folder/name) for name in ['command.json','stdout','stderr','counters.csv']}))
  save(folder/'result.json',rows[-1]);print(folder.name,passed,counters,flush=True)
save(out/'results.json',dict(passed=all(r['passed'] for r in rows),cases=rows,instrumented=True,primary_performance=False))
assert all(r['passed'] for r in rows)
for workers in [1,4]:
 for transport in ['smccc','mmio']:
  def count(variant,event):return next(r['counters'][event] for r in rows if r['mode']=='getpid' and r['workers']==workers and r['transport']==transport and r['variant']==variant)
  assert count('after','syscalls:sys_enter_timer_create')<count('before','syscalls:sys_enter_timer_create')/100
  assert count('after','syscalls:sys_enter_timer_delete')<count('before','syscalls:sys_enter_timer_delete')/100
work.rmdir()
