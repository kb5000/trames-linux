#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git -C runtime fetch /mnt/trames-output/linux-runtime-refresh-runtime.bundle HEAD
git -C runtime merge --ff-only --no-stat FETCH_HEAD
git -C cli fetch /mnt/trames-output/linux-runtime-refresh-cli.bundle HEAD
git -C cli merge --ff-only --no-stat FETCH_HEAD
git -c fetch.recurseSubmodules=false fetch /mnt/trames-output/linux-runtime-refresh-root.bundle HEAD
git merge --ff-only --no-stat FETCH_HEAD
git remote set-url origin https://github.com/project-trames/trames-linux.git
git submodule sync
python3 scripts/check-boundaries.py
python3 runtime/scripts/build-guest-cli.py
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-timer-before-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-timer-before-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-timer-before
python3 tests/acceptance/validate-memory.py --runner /home/main.guest/trames-kvm-timer-before --receipt /home/main.guest/trames-kvm-timer-before-build.json --output /home/main.guest/trames-kvm-timer-refresh-memory > /home/main.guest/trames-kvm-timer-refresh-memory.log 2>&1
python3 tests/acceptance/benchmark.py --runner /home/main.guest/trames-kvm-timer-before --receipt /home/main.guest/trames-kvm-timer-before-build.json --workers 1 4 --repeats 3 --workload cpu --workload getpid --workload idle --workload mmap --workload build --workload node --output /home/main.guest/trames-kvm-timer-before-performance > /home/main.guest/trames-kvm-timer-before-performance.log 2>&1
