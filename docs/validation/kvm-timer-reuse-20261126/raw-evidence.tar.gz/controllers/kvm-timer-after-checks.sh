#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git -c fetch.recurseSubmodules=false fetch /mnt/trames-output/kvm-timer-reuse-root.bundle HEAD
git merge --ff-only --no-stat FETCH_HEAD
cargo test -p trames-kvm --lib --release --locked deadline::tests -- --test-threads=1 > /home/main.guest/trames-kvm-timer-unit.log 2>&1
cargo clippy --workspace --all-targets --release --locked -- -D warnings > /home/main.guest/trames-kvm-timer-clippy.log 2>&1
cargo test --workspace --release --locked > /home/main.guest/trames-kvm-timer-tests.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport cargo test -p trames-kvm --lib --test hardware --release --locked -- --ignored --test-threads=1 > /home/main.guest/trames-kvm-timer-hardware-$transport.log 2>&1
done
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-timer-after-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-timer-after-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-timer-after
python3 tests/acceptance/validate-memory.py --runner /home/main.guest/trames-kvm-timer-after --receipt /home/main.guest/trames-kvm-timer-after-build.json --output /home/main.guest/trames-kvm-timer-after-memory > /home/main.guest/trames-kvm-timer-after-memory.log 2>&1
python3 scripts/validate-cpu.py --runner /home/main.guest/trames-kvm-timer-after --receipt /home/main.guest/trames-kvm-timer-after-build.json --output /home/main.guest/trames-kvm-timer-after-cpu > /home/main.guest/trames-kvm-timer-after-cpu.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport TRAMES_BINARY=/home/main.guest/trames-kvm-timer-after TRAMES_VALIDATION_OUTPUT=/home/main.guest/trames-kvm-timer-cli-$transport python3 scripts/validate-cli.py > /home/main.guest/trames-kvm-timer-cli-$transport.log 2>&1
done
python3 scripts/validate-applications.py --bundle /home/main.guest/trames-acceptance-bundle-v3 --runner /home/main.guest/trames-kvm-timer-after --receipt /home/main.guest/trames-kvm-timer-after-build.json --reference /home/main.guest/trames-applications-final-native --output /home/main.guest/trames-kvm-timer-applications > /home/main.guest/trames-kvm-timer-applications.log 2>&1
printf 'affected checks complete\n'
