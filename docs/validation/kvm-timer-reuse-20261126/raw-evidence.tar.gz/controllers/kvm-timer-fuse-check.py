from pathlib import Path
import json,os,shutil,subprocess,sys
project=Path('/home/main.guest/trames-linux-wsi-qualified')
sys.path.insert(0,str(project/'runtime/tests/acceptance'))
from common import digest,save
from run import execute,receipt,host
source=Path('/mnt/trames-output/kvm-timer-fuse-inputs')
out=Path('/home/main.guest/trames-kvm-timer-fuse');out.mkdir(exist_ok=False)
root=out/'rootfs';root.mkdir()
manifest=json.loads((source/'inputs.json').read_text())
for name,value in manifest['files'].items():assert digest(source/name)==value,name
subprocess.run(['tar','-xzf',str(source/'alpine-minirootfs.tar.gz'),'--no-same-owner','-C',str(root)],check=True)
tools=root/'opt/fuse-tool';tools.mkdir(parents=True)
for name in ['passthrough','passthrough_ll','client','workload.sh']:shutil.copy2(source/name,tools/name)
runner=Path('/home/main.guest/trames-kvm-timer-after')
build=receipt(Path('/home/main.guest/trames-kvm-timer-after-build.json'),runner)
save(out/'inputs.json',dict(build=build,host=host(),tools=manifest,controller_sha256=digest(Path(__file__)),
 scope='existing stock libfuse functional workload on KVM; no full-domain gVisor or hardware-device claim'))
expected=['busybox','mapping','copyout','metadata','aio','copy','transfer','cached','ring','unmount','daemon-stop','daemon-exit']
rows=[]
for transport in ['smccc','mmio']:
 for workers in [1,4]:
  for profile in ['lowlevel','writeback','highlevel']:
   name=f'{profile}-{transport}-{workers}';folder=out/name;folder.mkdir()
   for item in (root/'tmp').iterdir():
    if item.is_dir() and not item.is_symlink():shutil.rmtree(item)
    else:item.unlink()
   command=[runner,'run','--cpus',str(workers),'--rootfs',root,'--timeout-ms','180000','--','/bin/sh','/opt/fuse-tool/workload.sh',profile]
   save(folder/'command.json',dict(argv=[str(x) for x in command],transport=transport))
   result=execute(command,os.environ|{'TRAMES_KVM_TRANSPORT':transport},folder,185)
   for item in ['fuse-daemon.stdout','fuse-daemon.stderr','fuse-daemon.exit']:
    path=root/'tmp'/item
    if path.exists():shutil.copy2(path,folder/item)
   text=(folder/'stdout').read_text(errors='replace')
   checks={label:text.count('CASE '+label+' PASS\n')==1 for label in expected}
   writeback=profile!='writeback' or 'activating writeback' in (folder/'fuse-daemon.stderr').read_text(errors='replace')
   passed=result['status']=='completed' and result['exit_code']==0 and all(checks.values()) and text.endswith('WORKLOAD '+profile+' FAILED=0\n') and writeback and (folder/'fuse-daemon.exit').read_text().strip()=='0'
   row=dict(id=name,**result,passed=passed,checks=checks,writeback=writeback,logs={p.name:digest(p) for p in folder.iterdir() if p.is_file()})
   save(folder/'result.json',row);rows.append(row);save(out/'results.json',dict(cases=rows,passed=sum(r['passed'] for r in rows),planned=12))
   print(name,passed,result['exit_code'],checks,flush=True)
save(out/'results.json',dict(cases=rows,passed=sum(r['passed'] for r in rows),planned=12,checks_passed=sum(sum(r['checks'].values()) for r in rows)))
assert all(r['passed'] for r in rows)
