from pathlib import Path
import tarfile,os,json
base=Path('/home/main.guest');prefix='trames-kvm-timer-'
paths={prefix+'before-performance':'before-performance',prefix+'after-performance':'after-performance',prefix+'paired-micro':'paired-micro',prefix+'after-memory':'memory',prefix+'after-cpu':'cpu',prefix+'applications':'applications',prefix+'cli-smccc':'cli-smccc',prefix+'cli-mmio':'cli-mmio',prefix+'counters':'counters',prefix+'fuse':'fuse-initial',prefix+'fuse-final':'fuse-final',prefix+'fuse-cli-smccc':'fuse-cli-smccc',prefix+'fuse-cli-mmio':'fuse-cli-mmio','trames-applications-final-native':'applications-native'}
files=[p for p in base.glob(prefix+'*.log')]+[p for p in base.glob(prefix+'*build.json')]
with tarfile.open('/mnt/trames-output/kvm-timer-raw-evidence.tgz','w:gz') as archive:
 for source,target in paths.items():
  root=base/source
  assert root.is_dir(),root
  for folder,dirs,names in os.walk(root):
   dirs[:]=[d for d in dirs if d not in ['rootfs','.git','__pycache__']]
   for name in names:
    file=Path(folder)/name
    if not file.is_file() or file.is_symlink():continue
    with file.open('rb') as stream: magic=stream.read(4)
    if magic==b'\x7fELF':continue
    archive.add(file,arcname=str(Path(target)/file.relative_to(root)),recursive=False)
 for file in files:archive.add(file,arcname='builds-and-logs/'+file.name,recursive=False)
 for file in Path('/mnt/trames-output').glob('kvm-timer-*.py'):archive.add(file,arcname='controllers/'+file.name,recursive=False)
 for file in Path('/mnt/trames-output').glob('kvm-timer-*.sh'):archive.add(file,arcname='controllers/'+file.name,recursive=False)
print('exported',Path('/mnt/trames-output/kvm-timer-raw-evidence.tgz').stat().st_size,flush=True)
