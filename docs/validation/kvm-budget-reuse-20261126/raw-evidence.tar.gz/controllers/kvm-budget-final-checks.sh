#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git -C runtime apply -R /mnt/trames-output/kvm-budget-android-test.patch
git -C runtime fetch /mnt/trames-output/runtime-budget-android-fix.bundle HEAD
git -C runtime merge --ff-only --no-stat FETCH_HEAD
cp /mnt/trames-output/kvm-budget-final-deadline.rs crates/trames-kvm/src/deadline.rs
cargo clippy --workspace --all-targets --release --locked -- -D warnings > /home/main.guest/trames-kvm-budget-final-clippy.log 2>&1
cargo test --workspace --release --locked > /home/main.guest/trames-kvm-budget-final-tests.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport cargo test -p trames-kvm --lib --test hardware --release --locked -- --ignored --test-threads=1 > /home/main.guest/trames-kvm-budget-final-hardware-$transport.log 2>&1
done
