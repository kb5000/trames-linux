# SPDX-License-Identifier: GPL-3.0-or-later
# Run under sudo unshare --mount --propagation private; no host mounts change.
import ctypes,errno,json,os,tempfile
from pathlib import Path
libc=ctypes.CDLL(None,use_errno=True)
libc.mount.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_char_p,ctypes.c_ulong,ctypes.c_char_p]
libc.umount2.argtypes=[ctypes.c_char_p,ctypes.c_int]
root=Path(tempfile.mkdtemp(prefix='trames-native-remount-'))
def mount(source,target,kind,flags,data=None):
 def raw(v):return os.fsencode(v) if v is not None else None
 if libc.mount(raw(source),raw(target),raw(kind),flags,raw(data)):
  raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
def create(path):
 try:path.write_bytes(b'value');return 0
 except OSError as e:return e.errno
try:
 mount('tmpfs',root,'tmpfs',0,'size=4m')
 for name in ['system','data','mnt']:(root/name).mkdir()
 mount(root/'data',root/'data',None,4096)
 mount('tmpfs',root/'mnt','tmpfs',0,'size=4m')
 mount(None,root,None,32|4096|1|4)
 result=dict(bind_readonly_root_system_errno=create(root/'system/new'),bind_readonly_data_errno=create(root/'data/live'))
 mount(None,root,None,32|1)
 result.update(super_readonly_data_errno=create(root/'data/wide'),independent_tmpfs_errno=create(root/'mnt/live'))
 assert result==dict(bind_readonly_root_system_errno=30,bind_readonly_data_errno=0,super_readonly_data_errno=30,independent_tmpfs_errno=0),result
 print(json.dumps(result,indent=2))
finally:
 libc.umount2(os.fsencode(root),2)
 root.rmdir()
