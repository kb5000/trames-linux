#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
export CARGO_INCREMENTAL=0
cd /home/main.guest/trames-linux-wsi-qualified
# Only this test source changes; the current production implementation is retained.
cp /mnt/trames-output/kvm-budget-negative-deadline.rs crates/trames-kvm/src/deadline.rs
if cargo test -p trames-kvm --lib --release --locked explicit_kick_interrupts_host_pipe_io -- --exact --test-threads=1 > /home/main.guest/trames-kvm-budget-kick-negative.log 2>&1; then
 # The full test name is required by --exact; retry the explicit module path.
 cargo test -p trames-kvm --lib --release --locked deadline::tests::explicit_kick_interrupts_host_pipe_io -- --exact --test-threads=1 > /home/main.guest/trames-kvm-budget-kick-negative.log 2>&1 && exit 1
fi
python3 - <<'PY'
from pathlib import Path
s=Path('/home/main.guest/trames-kvm-budget-kick-negative.log').read_text()
assert 'explicit_kick_interrupts_host_pipe_io ... FAILED' in s and 'left: 1' in s and 'right: -1' in s
print('Confirmed old shared SA_RESTART signal incorrectly restarts an explicit kick during host read')
PY
