#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_INCREMENTAL=0
export PYTHONDONTWRITEBYTECODE=1
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git show HEAD:crates/trames-kvm/src/deadline.rs > crates/trames-kvm/src/deadline.rs
git -c fetch.recurseSubmodules=false fetch /mnt/trames-output/kvm-budget-final-candidate.bundle HEAD
git merge --ff-only --no-stat FETCH_HEAD
python3 scripts/check-boundaries.py
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-budget-final-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-budget-final-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-budget-final
python3 scripts/validate-clock.py --runner /home/main.guest/trames-kvm-budget-final --receipt /home/main.guest/trames-kvm-budget-final-build.json --output /home/main.guest/trames-kvm-budget-final-clock > /home/main.guest/trames-kvm-budget-final-clock.log 2>&1
python3 tests/acceptance/validate-memory.py --runner /home/main.guest/trames-kvm-budget-final --receipt /home/main.guest/trames-kvm-budget-final-build.json --output /home/main.guest/trames-kvm-budget-final-memory > /home/main.guest/trames-kvm-budget-final-memory.log 2>&1
python3 scripts/validate-cpu.py --runner /home/main.guest/trames-kvm-budget-final --receipt /home/main.guest/trames-kvm-budget-final-build.json --output /home/main.guest/trames-kvm-budget-final-cpu > /home/main.guest/trames-kvm-budget-final-cpu.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport TRAMES_BINARY=/home/main.guest/trames-kvm-budget-final TRAMES_VALIDATION_OUTPUT=/home/main.guest/trames-kvm-budget-final-cli-$transport python3 scripts/validate-cli.py > /home/main.guest/trames-kvm-budget-final-cli-$transport.log 2>&1
done
python3 scripts/validate-applications.py --bundle /home/main.guest/trames-acceptance-bundle-v3 --runner /home/main.guest/trames-kvm-budget-final --receipt /home/main.guest/trames-kvm-budget-final-build.json --reference /home/main.guest/trames-applications-final-native --output /home/main.guest/trames-kvm-budget-final-applications > /home/main.guest/trames-kvm-budget-final-applications.log 2>&1
python3 tests/acceptance/benchmark.py --runner /home/main.guest/trames-kvm-budget-final --receipt /home/main.guest/trames-kvm-budget-final-build.json --baseline-runner /home/main.guest/trames-kvm-budget-before --baseline-receipt /home/main.guest/trames-kvm-budget-before-build.json --workload cpu --workload getpid --workload pipe --workload futex --workload mmap --workload fork-exec --workload build --workload node --workers 1 4 --repeats 3 --output /home/main.guest/trames-kvm-budget-final-performance > /home/main.guest/trames-kvm-budget-final-performance.log 2>&1
