#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_INCREMENTAL=0
export PYTHONDONTWRITEBYTECODE=1
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git -C cli fetch /mnt/trames-output/cli-budget-pin.bundle HEAD
git -C cli merge --ff-only --no-stat FETCH_HEAD
python3 - <<'PY'
from pathlib import Path
import json,shutil,hashlib,subprocess
p=Path('tests/acceptance/__pycache__');files=list(p.iterdir())
assert all(f.is_file() and f.suffix=='.pyc' for f in files)
Path('/mnt/trames-output/kvm-budget-bytecode-cleanup.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},indent=2)+'\n')
shutil.rmtree(p)
assert not subprocess.check_output(['git','status','--porcelain']).strip()
PY
for variant in before after; do
 cp /home/main.guest/trames-kvm-budget-$variant-build.json /home/main.guest/trames-kvm-budget-$variant-initial-build.json
done
git switch --detach f52564f
python3 scripts/check-boundaries.py
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-budget-before-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-budget-before-clean-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-budget-before-clean
git switch main
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-budget-after-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-budget-after-clean-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-budget-after-clean
python3 - <<'PY'
import json,hashlib
from pathlib import Path
rows=[]
for v in ['before','after']:
 old=Path('/home/main.guest/trames-kvm-budget-'+v);new=Path(str(old)+'-clean')
 row=dict(variant=v,initial_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),clean_sha256=hashlib.sha256(new.read_bytes()).hexdigest());rows.append(row)
 assert not json.loads(Path(str(old)+'-build.json').read_text())['sources']['product']['dirty']
Path('/mnt/trames-output/kvm-budget-clean-identity.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
PY
