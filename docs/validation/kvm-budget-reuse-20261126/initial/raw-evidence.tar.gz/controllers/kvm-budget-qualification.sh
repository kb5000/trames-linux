#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
git apply -R /mnt/trames-output/kvm-budget.patch
git -c fetch.recurseSubmodules=false fetch /mnt/trames-output/kvm-budget-candidate.bundle HEAD
git merge --ff-only --no-stat FETCH_HEAD
python3 scripts/check-boundaries.py
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-budget-after-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-budget-after-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-budget-after
python3 scripts/validate-clock.py --runner /home/main.guest/trames-kvm-budget-after --receipt /home/main.guest/trames-kvm-budget-after-build.json --output /home/main.guest/trames-kvm-budget-clock > /home/main.guest/trames-kvm-budget-clock.log 2>&1
python3 tests/acceptance/validate-memory.py --runner /home/main.guest/trames-kvm-budget-after --receipt /home/main.guest/trames-kvm-budget-after-build.json --output /home/main.guest/trames-kvm-budget-memory > /home/main.guest/trames-kvm-budget-memory.log 2>&1
python3 scripts/validate-cpu.py --runner /home/main.guest/trames-kvm-budget-after --receipt /home/main.guest/trames-kvm-budget-after-build.json --output /home/main.guest/trames-kvm-budget-cpu > /home/main.guest/trames-kvm-budget-cpu.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport TRAMES_BINARY=/home/main.guest/trames-kvm-budget-after TRAMES_VALIDATION_OUTPUT=/home/main.guest/trames-kvm-budget-cli-$transport python3 scripts/validate-cli.py > /home/main.guest/trames-kvm-budget-cli-$transport.log 2>&1
done
python3 scripts/validate-applications.py --bundle /home/main.guest/trames-acceptance-bundle-v3 --runner /home/main.guest/trames-kvm-budget-after --receipt /home/main.guest/trames-kvm-budget-after-build.json --reference /home/main.guest/trames-applications-final-native --output /home/main.guest/trames-kvm-budget-applications > /home/main.guest/trames-kvm-budget-applications.log 2>&1
