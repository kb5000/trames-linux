#!/bin/sh
set -eu
export PYTHONDONTWRITEBYTECODE=1
export PATH=/home/main.guest/.cargo/bin:$PATH
cd /home/main.guest/trames-linux-wsi-qualified
python3 tests/acceptance/benchmark.py --runner /home/main.guest/trames-kvm-budget-after --receipt /home/main.guest/trames-kvm-budget-after-build.json --baseline-runner /home/main.guest/trames-kvm-budget-before --baseline-receipt /home/main.guest/trames-kvm-budget-before-build.json --workload cpu --workload getpid --workload pipe --workload futex --workload mmap --workload fork-exec --workload build --workload node --workers 1 4 --repeats 3 --output /home/main.guest/trames-kvm-budget-performance > /home/main.guest/trames-kvm-budget-performance.log 2>&1
