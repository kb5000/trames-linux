#!/bin/sh
set -eu
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR=/home/main.guest/trames-linux-engine/target
cd /home/main.guest/trames-linux-wsi-qualified
mv /home/main.guest/trames-kvm-budget-before-build.json /home/main.guest/trames-kvm-budget-interface-build.json
git -c fetch.recurseSubmodules=false fetch /mnt/trames-output/kvm-budget-metadata.bundle HEAD
git merge --ff-only --no-stat FETCH_HEAD
python3 scripts/check-boundaries.py
python3 runtime/tests/acceptance/build.py --product . --runtime runtime --binary "$CARGO_TARGET_DIR/release/trames" --receipt /home/main.guest/trames-kvm-budget-before-build.json -- cargo build --workspace --release --locked > /home/main.guest/trames-kvm-budget-before-final-build.log 2>&1
cp "$CARGO_TARGET_DIR/release/trames" /home/main.guest/trames-kvm-budget-before
git apply /mnt/trames-output/kvm-budget.patch
cargo clippy --workspace --all-targets --release --locked -- -D warnings > /home/main.guest/trames-kvm-budget-clippy.log 2>&1
cargo test --workspace --release --locked > /home/main.guest/trames-kvm-budget-tests.log 2>&1
for transport in smccc mmio; do
 TRAMES_KVM_TRANSPORT=$transport cargo test -p trames-kvm --lib --test hardware --release --locked -- --ignored --test-threads=1 > /home/main.guest/trames-kvm-budget-hardware-$transport.log 2>&1
done
