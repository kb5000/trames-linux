from pathlib import Path
import subprocess,os,json,hashlib,time
out=Path('/home/main.guest/trames-clock-before');out.mkdir(exist_ok=False)
root=out/'rootfs';(root/'test').mkdir(parents=True);(root/'work').mkdir()
source=Path('/mnt/trames-output/clock-consistency.c');binary=root/'test/clock-probe'
build=['cc','-O2','-static','-Wall','-Wextra','-Werror',str(source),'-o',str(binary)];subprocess.run(build,check=True)
runner=Path('/home/main.guest/trames-kvm-joined-writes-compact-runner')
rows=[];jobs=[]
for label,args,env in [('native',[binary,'25000',root/'work/native'],os.environ.copy()),('smccc',[runner,'run','--cpus','1','--rootfs',root,'--timeout-ms','40000','--','/test/clock-probe','25000','/work/smccc'],os.environ|{'TRAMES_KVM_TRANSPORT':'smccc'}),('mmio',[runner,'run','--cpus','1','--rootfs',root,'--timeout-ms','40000','--','/test/clock-probe','25000','/work/mmio'],os.environ|{'TRAMES_KVM_TRANSPORT':'mmio'})]:
 folder=out/label;folder.mkdir();(folder/'command.json').write_text(json.dumps([str(a) for a in args],indent=2)+'\n')
 stdout=(folder/'stdout').open('wb');stderr=(folder/'stderr').open('wb');p=subprocess.Popen(args,env=env,stdout=stdout,stderr=stderr);jobs.append((label,p,stdout,stderr))
for label,p,stdout,stderr in jobs:
 code=p.wait(timeout=45);stdout.close();stderr.close();summary=json.loads((out/label/'stdout').read_text().splitlines()[-1]);rows.append(dict(label=label,exit_code=code,summary=summary));print(rows[-1],flush=True)
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
subprocess.run(['tar','-czf','/mnt/trames-output/clock-before.tgz','--exclude=rootfs','-C',str(out),'.'],check=True)
