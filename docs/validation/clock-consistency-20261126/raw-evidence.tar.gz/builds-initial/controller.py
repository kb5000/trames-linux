# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
repo=Path('/home/main.guest/trames-linux-wsi-qualified')
sys.path.insert(0,str(repo/'runtime/tests/acceptance'))
from common import digest,save
from run import execute,receipt
out=Path('/home/main.guest/trames-clock-builds');out.mkdir(exist_ok=False)
original=Path('/home/main.guest/trames-kvm-timer-before-performance/rootfs')
inputs={str(p.relative_to(original)):digest(p) for p in sorted(original.rglob('*')) if p.is_file() and p.relative_to(original).parts[0]!='work'}
root=out/'rootfs'
shutil.copytree(original,root,copy_function=os.link,ignore=shutil.ignore_patterns('work'))
(root/'work').mkdir()
variants={name:Path('/home/main.guest/'+name) for name in ('trames-kvm-timer-fuse-runner','trames-kvm-joined-writes-compact-runner')}
receipts={name:receipt(Path(str(path).replace('-runner','-build.json')),path) for name,path in variants.items()}
shutil.copy2(root/'test/performance',out/'original-performance-elf')
shutil.copy2(__file__,out/'controller.py')
save(out/'inputs.json',dict(immutable_files=inputs,builds=receipts,controller_sha256=digest(Path(__file__)),fixture_binary_sha256=digest(root/'test/performance'),iterations=12,workers=[1,4],lanes=['native','baseline-smccc','candidate-smccc','baseline-mmio','candidate-mmio'],timing_qualification=False))
rows=[];native={}
for workers in (1,4):
 for lane in ['native','baseline-smccc','candidate-smccc','baseline-mmio','candidate-mmio']:
  name=f'{lane}-{workers}';folder=out/name;folder.mkdir();work=root/'work'/name;work.mkdir()
  env=dict(PATH='/usr/bin:/bin',HOME='/tmp',LANG='C',LC_ALL='C',TZ='UTC')
  if lane=='native':args=[root/'test/performance','build','12',str(workers),work]
  else:
   variant,transport=lane.split('-');runner=list(variants.values())[0 if variant=='baseline' else 1]
   env['TRAMES_KVM_TRANSPORT']=transport
   args=[runner,'run','--cpus',str(workers),'--rootfs',root,'--timeout-ms','120000','--','/test/performance','build','12',str(workers),'/work/'+name]
  args=[str(v) for v in args];save(folder/'command.json',dict(argv=args,environment=env))
  began=time.time_ns();result=execute(args,env,folder,125)
  try:value=json.loads((folder/'stdout').read_text())
  except ValueError:value=None
  objects={p.name:digest(p) for p in sorted(work.glob('*.o'))}
  if lane=='native':native[workers]=dict(value=value,objects=objects)
  reference=native[workers]
  good=(result['status']=='completed' and result['exit_code']==0 and not (folder/'stderr').read_bytes() and isinstance(value,dict) and set(value)=={'mode','concurrency','tasks','iterations','checksum','work_ns'} and value['mode']=='build' and value['concurrency']==workers and value['iterations']==12 and value['tasks']==workers and value['work_ns']>0 and len(objects)==12 and value['checksum']==reference['value']['checksum'] and objects==reference['objects'])
  row=dict(id=name,**result,status='passed' if good else 'failed',work=value,objects=objects,started_realtime_ns=began,logs={key:digest(folder/key) for key in ('stdout','stderr','command.json')})
  save(folder/'result.json',row);rows.append(row);save(out/'samples.json',rows)
  print(name,row['status'],round(result['seconds'],3),flush=True)
  shutil.rmtree(work)
assert {str(p.relative_to(original)):digest(p) for p in sorted(original.rglob('*')) if p.is_file() and p.relative_to(original).parts[0]!='work'}==inputs
save(out/'results.json',dict(passed=sum(r['status']=='passed' for r in rows),planned=10,cases=rows,timing_qualification=False))
raise SystemExit(0 if all(r['status']=='passed' for r in rows) else 1)
