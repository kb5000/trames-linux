from pathlib import Path
import json,hashlib,shutil,subprocess
base=Path('/home/main.guest');out=Path('/mnt/trames-output/clock-policy')
original=base/'trames-kvm-timer-before-performance/rootfs'
inputs=json.loads((base/'trames-clock-builds-qualified/inputs.json').read_text())['immutable_files']
def hashes(root):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.relative_to(root).parts[0]!='work'}
assert hashes(original)==inputs
rows=[];before=shutil.disk_usage(base).free
for name in ('trames-clock-before','trames-clock-after-initial','trames-clock-qualified','trames-clock-builds','trames-clock-builds-qualified'):
 root=base/name/'rootfs'
 if name.startswith('trames-clock-builds'):
  assert hashes(root)==inputs
 elif name=='trames-clock-qualified':
  assert hashlib.sha256((root/'test/clock-probe').read_bytes()).hexdigest()==hashlib.sha256((root.parent/'original-clock-elf').read_bytes()).hexdigest()
 else:
  assert hashlib.sha256((root/'test/clock-probe').read_bytes()).hexdigest()==hashlib.sha256(Path('/mnt/trames-output/clock-before-elf').read_bytes()).hexdigest()
 rows.append(dict(path=str(root),allocated_bytes=sum(p.stat().st_blocks*512 for p in root.rglob('*') if p.is_file())))
 shutil.rmtree(root)
assert hashes(original)==inputs
result=dict(removed_only_this_task_rootfs=rows,free_bytes_before=before,free_bytes_after=shutil.disk_usage(base).free,immutable_master_files=169,immutable_master_unchanged=True)
(out/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
